// Purpose of this directory

// Add all template raw files in this directory

// All files can be access by using `module_asset('Resources/assets/statics/<target-file-path>', config('passwordchange.name'))`
