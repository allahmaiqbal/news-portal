{{ module_vite_assets_unique_hot_path(['Resources/assets/js/registerVueComponents.js'], 'build-tag') }}
<x-backend.backend-layout>
    @section('content')
    @show
</x-backend.backend-layout>
