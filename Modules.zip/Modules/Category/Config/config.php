<?php

return [
    'name' => 'Category'
];
