/**
 * Register all react components
 */

import "./components/DemoComponent"; // Demo component
