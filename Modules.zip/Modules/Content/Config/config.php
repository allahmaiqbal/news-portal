<?php

return [
    'name' => 'Content'
];
