<?php

namespace App\Console\Commands\Pint;

use Illuminate\Console\Command;

class PintCommand extends PintRunCommand
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'pint';
}
