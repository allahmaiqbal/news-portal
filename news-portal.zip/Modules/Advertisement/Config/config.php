<?php

return [
    'name' => 'Advertisement'
];
