import _ from "lodash";
window._ = _;
