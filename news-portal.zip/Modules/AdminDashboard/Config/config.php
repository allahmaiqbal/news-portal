<?php

return [
    'name' => 'AdminDashboard'
];
