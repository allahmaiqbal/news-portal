<x-backend.backend-layout>
    @section('content')
    @show
</x-backend.backend-layout>
