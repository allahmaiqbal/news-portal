<?php

return [
    'name' => 'Tag'
];
