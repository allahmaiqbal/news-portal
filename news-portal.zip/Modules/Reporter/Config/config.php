<?php

return [
    'name' => 'Reporter'
];
