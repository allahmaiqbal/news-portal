<?php

return [
    'name' => 'SubCategory'
];
