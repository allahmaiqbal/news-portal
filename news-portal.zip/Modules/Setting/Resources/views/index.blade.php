@extends('setting::layouts.master')

@section('title', 'Setting')

@section('content')

@endsection
