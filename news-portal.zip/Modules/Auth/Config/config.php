<?php

return [
    'name' => 'Auth'
];
