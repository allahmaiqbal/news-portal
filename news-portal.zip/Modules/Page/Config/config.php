<?php

return [
    'name' => 'Page'
];
