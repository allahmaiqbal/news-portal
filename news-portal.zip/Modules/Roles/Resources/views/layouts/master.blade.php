{{-- @push('styles')

@endpush --}}

{{-- <x-app-layout>
    @section('content')
    @show
</x-app-layout> --}}
<x-backend.backend-layout>
    @section('content')
    @show
</x-backend.backend-layout>
