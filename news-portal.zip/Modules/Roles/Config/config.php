<?php

return [
    'name' => 'Roles'
];
