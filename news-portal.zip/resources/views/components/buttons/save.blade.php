<button type="submit" class="btn btn-primary">
    <i class="bi bi-plus-square"></i>
    <span class="p-1">Save</span>
</button>
