<button type="reset" class="btn btn-warning me-2">
    <i class="bi bi-dash-square"></i>
    <span class="p-1">Reset</span>
</button>
