@props([
'route' => ''
])
<a href="{{ $route }}" title="Go back"
   class="pe-0 ms-auto print-none top-icon-button mb-2 mt-3">
    <i class="bi bi-arrow-left"></i>
</a>
