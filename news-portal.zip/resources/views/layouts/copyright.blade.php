<p class="text-center text-muted">&copy; {{ date('Y') }} - {{ config('app.name', 'MaxSOP') }}</p>
