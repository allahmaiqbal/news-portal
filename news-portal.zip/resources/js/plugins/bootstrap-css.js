import bootstrap from "bootstrap/dist/js/bootstrap.bundle";
window.bootstrap = bootstrap;

// Enable tooltip globally
var tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
);
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
});
