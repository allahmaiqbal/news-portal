// Purpose of this directory

// Add all template raw files in this directory

// All files can be access by using `Vite::asset('resources/statics/<target-file-path>')`
