// const contact = document.querySelector(".side-contact");
// const menu = document.querySelector(".dropdown-md");
// const close = document.querySelector(".close-btn");

// contact.addEventListener("click", () => {
//   console.log("khalil");
//  menu.classList.add('visible')
// });
// close.addEventListener("click", () => {
//   console.log("khalil");
//   menu.classList.remove('visible')
// });

// import '../../../js/plugins'
// import '../../../js/registerVueComponents'
import '../../../js/plugins'
import '../../../js/registerVueComponents'
