<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SubCategory\\Providers\\SubCategoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SubCategory\\Providers\\SubCategoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);