<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Repoter\\Providers\\RepoterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Repoter\\Providers\\RepoterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);