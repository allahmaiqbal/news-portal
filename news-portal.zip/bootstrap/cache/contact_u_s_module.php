<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ContactUS\\Providers\\ContactUSServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ContactUS\\Providers\\ContactUSServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);