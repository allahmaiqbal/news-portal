<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PasswordChange\\Providers\\PasswordChangeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PasswordChange\\Providers\\PasswordChangeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);