<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Posts\\Providers\\PostsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Posts\\Providers\\PostsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);