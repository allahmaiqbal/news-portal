<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminDashboard\\Providers\\AdminDashboardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminDashboard\\Providers\\AdminDashboardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);