<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Advertisement\\Providers\\AdvertisementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Advertisement\\Providers\\AdvertisementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);