<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);